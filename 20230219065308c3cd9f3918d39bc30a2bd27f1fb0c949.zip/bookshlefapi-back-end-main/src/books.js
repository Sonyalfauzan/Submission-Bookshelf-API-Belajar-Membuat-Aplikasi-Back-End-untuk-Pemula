// array kosong untuk menyimpan semua properti book
const books = [];

module.exports = books;
